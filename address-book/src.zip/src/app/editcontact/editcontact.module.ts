import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EditcontactRoutingModule } from './editcontact-routing.module';
import { EditcontactComponent } from './editcontact.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [EditcontactComponent],
  imports: [
    CommonModule,
    EditcontactRoutingModule,
    FormsModule
  ]
})
export class EditcontactModule { }
